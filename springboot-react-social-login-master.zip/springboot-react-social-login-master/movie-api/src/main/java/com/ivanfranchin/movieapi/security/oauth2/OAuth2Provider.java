package com.ivanfranchin.movieapi.security.oauth2;

public enum OAuth2Provider {

    LOCAL, GITHUB
}
