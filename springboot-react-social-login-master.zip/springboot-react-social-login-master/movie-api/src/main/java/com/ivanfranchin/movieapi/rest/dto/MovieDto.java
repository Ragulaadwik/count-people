package com.ivanfranchin.movieapi.rest.dto;

public record MovieDto(String imdb, String title, String poster, String createdAt) {
}
