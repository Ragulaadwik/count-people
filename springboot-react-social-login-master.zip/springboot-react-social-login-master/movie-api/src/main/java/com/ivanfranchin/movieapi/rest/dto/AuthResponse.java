package com.ivanfranchin.movieapi.rest.dto;

public record AuthResponse(String accessToken) {
}
